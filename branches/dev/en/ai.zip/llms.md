# de.medizininformatikinitiative.template.selftest#0.1.0: MII KDS IG Template — Self-Test(en)

## Pages

* [Home](index.md)
* [Artifacts Summary](artifacts.md)

## Resources

### Logicals

* [Self-Test Model](StructureDefinition-selftest-model.md)

### ImplementationGuides

* [MII KDS IG Template — Self-Test](ImplementationGuide-de.medizininformatikinitiative.template.selftest.md)
