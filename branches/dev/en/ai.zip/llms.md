# de.medizininformatikinitiative.template.preview#1.2.0: MII KDS IG Template — Preview(en)

## Pages

* [Home](index.md)
* [Artifacts Summary](artifacts.md)
* [Translation information](translationinfo.md)

## Resources

### Logicals

* [Preview Model](StructureDefinition-preview-model.md)

### ImplementationGuides

* [MII KDS IG Template — Preview](ImplementationGuide-de.medizininformatikinitiative.template.preview.md)
