# de.medizininformatikinitiative.template.preview#0.6.0: MII KDS IG Template — Preview(en)

## Pages

* [Home](index.md)
* [Translation information](translationinfo.md)
* [Artifacts Summary](artifacts.md)

## Resources

### Logicals

* [Preview Model](StructureDefinition-preview-model.md)

### ImplementationGuides

* [MII KDS IG Template — Preview](ImplementationGuide-de.medizininformatikinitiative.template.preview.md)
