# Artifacts Summary - MII KDS IG Template — Self-Test v0.1.0

* [**Table of Contents**](toc.md)
* **Artifacts Summary**

## Artifacts Summary

 There is no translation page available for the current page, so it has been rendered in the default language 

This page provides a list of the FHIR artifacts defined as part of this implementation guide.

### Structures: Logical Models 

These define data models that represent the domain covered by this implementation guide in more business-friendly terms than the underlying FHIR resources.

| | |
| :--- | :--- |
| [ Self-Test Model  ](StructureDefinition-selftest-model.md) | Minimal logical model that exists only so the template self-test IG builds and its artifact layout renders; not an MII artifact. |

