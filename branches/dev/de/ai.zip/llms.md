# de.medizininformatikinitiative.template.selftest#0.1.0: MII KDS IG Template — Self-Test(de)

## Pages

* [Home](index.md)
* [Artefaktübersicht](artifacts.md)

## Resources

### Logicals

* [Self-Test Model](StructureDefinition-selftest-model.md)

### ImplementationGuides

* [MII KDS IG Template — Self-Test](ImplementationGuide-de.medizininformatikinitiative.template.selftest.md)
