# Self-Test Palette - MII KDS IG Template — Self-Test v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Self-Test Palette**

## CodeSystem: Self-Test Palette () 

| | |
| :--- | :--- |
| **:https://github.com/forschungsgruppe-digital-health/ig-template-mii-kds/CodeSystem/selftest-palette | **:0.1.0 |
| Draft | **:SelfTestPalette |

 
Two arbitrary codes so the self-test IG renders a CodeSystem page; not an MII artifact. 

* This CodeSystem is not used here; it may be used elsewhere (e.g. specifications and/or implementations that use this content)

-------

 . 



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "selftest-palette",
  "url" : "https://github.com/forschungsgruppe-digital-health/ig-template-mii-kds/CodeSystem/selftest-palette",
  "version" : "0.1.0",
  "name" : "SelfTestPalette",
  "title" : "Self-Test Palette",
  "status" : "draft",
  "experimental" : true,
  "date" : "2026-07-22T18:13:08+00:00",
  "publisher" : "Forschungsgruppe Digital Health, TU Dresden",
  "contact" : [{
    "name" : "Forschungsgruppe Digital Health, TU Dresden",
    "telecom" : [{
      "system" : "url",
      "value" : "https://github.com/forschungsgruppe-digital-health"
    }]
  }],
  "description" : "Two arbitrary codes so the self-test IG renders a CodeSystem page; not an MII artifact.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DE",
      "display" : "Germany"
    }]
  }],
  "caseSensitive" : true,
  "content" : "complete",
  "count" : 2,
  "concept" : [{
    "code" : "primary",
    "display" : "Primary",
    "definition" : "Stands in for the template's primary brand colour slot."
  },
  {
    "code" : "accent",
    "display" : "Accent",
    "definition" : "Stands in for the template's accent colour slot."
  }]
}

```
