# de.medizininformatikinitiative.template.preview#1.2.1: MII KDS IG Template — Preview(de)

## Pages

* [Startseite](index.md)
* [Artefaktübersicht](artifacts.md)
* [Hinweise zur Übersetzung](translationinfo.md)

## Resources

### Logicals

* [Preview Model](StructureDefinition-preview-model.md)

### ImplementationGuides

* [MII KDS IG Template — Preview](ImplementationGuide-de.medizininformatikinitiative.template.preview.md)
