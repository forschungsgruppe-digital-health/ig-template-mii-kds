# de.medizininformatikinitiative.template.preview#1.2.0: MII KDS IG Template — Preview(de)

## Pages

* [Startseite](index.md)
* [Hinweise zur Übersetzung](translationinfo.md)
* [Artefaktübersicht](artifacts.md)

## Resources

### Logicals

* [Preview Model](StructureDefinition-preview-model.md)

### ImplementationGuides

* [MII KDS IG Template — Preview](ImplementationGuide-de.medizininformatikinitiative.template.preview.md)
